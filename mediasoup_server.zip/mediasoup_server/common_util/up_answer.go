package common_util

import (
	"fmt"
	"mediasoup_server/bean"
	"strings"
	"time"
)

// 生成上行answerSdp
func GenerateUpAnswerSDP(
	iceUfrag string,
	icePwd string,
	fingerprint string,
	fingerprintHash string,
	candidates []bean.IceCandidate,
) string {
	now := time.Now()
	unixNano := now.UnixNano()
	origin := fmt.Sprintf("o=- %d 2 IN IP4 127.0.0.1", unixNano)

	port := 0
	ip := ""
	var udpCandidate = ""
	for _, cand := range candidates {
		if cand.Protocol == "udp" {
			udpCandidate = fmt.Sprintf(
				"a=candidate:%s 1 %s %d %s %d typ %s generation 0",
				cand.Foundation,
				cand.Protocol,
				cand.Priority,
				cand.IP,
				cand.Port,
				cand.Type,
			)
		}
		port = cand.Port
		ip = cand.IP
	}

	audioMid := "0"
	videoMid := "1"

	sdpLines := []string{
		"v=0",
		origin,
		"s=-",
		"t=0 0",
		fmt.Sprintf("a=group:BUNDLE %s %s", audioMid, videoMid),
		"a=msid-semantic: WMS",
		//"a=ice-lite",
		fmt.Sprintf("m=audio %d UDP/TLS/RTP/SAVPF 111", port),
		fmt.Sprintf("c=IN IP4 %s", ip),
		"a=rtcp:9 IN IP4 0.0.0.0",
		udpCandidate,
		fmt.Sprintf("a=ice-ufrag:%s", iceUfrag),
		fmt.Sprintf("a=ice-pwd:%s", icePwd),
		"a=ice-options:renomination",
		fmt.Sprintf("a=fingerprint:%s %s", fingerprintHash, fingerprint),
		"a=setup:active",
		fmt.Sprintf("a=mid:%s", audioMid),
		"a=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid",
		"a=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time",
		"a=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01",
		"a=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level",
		"a=recvonly",
		"a=rtcp-mux",
		"a=rtcp-rsize",
		"a=rtpmap:111 opus/48000/2",
		"a=rtcp-fb:111 transport-cc",
		"a=rtcp-fb:111 nack",
		"a=fmtp:111 stereo=1;usedtx=1;useinbandfec=1",
		fmt.Sprintf("m=video %d UDP/TLS/RTP/SAVPF 96 97", port),
		fmt.Sprintf("c=IN IP4 %s", ip),
		"a=rtcp:9 IN IP4 0.0.0.0",
		udpCandidate,
		fmt.Sprintf("a=ice-ufrag:%s", iceUfrag),
		fmt.Sprintf("a=ice-pwd:%s", icePwd),
		"a=ice-options:renomination",
		fmt.Sprintf("a=fingerprint:%s %s", fingerprintHash, fingerprint),
		"a=setup:active",
		fmt.Sprintf("a=mid:%s", videoMid),
		"a=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid",
		"a=extmap:10 urn:ietf:params:rtp-hdrext:sdes:rtp-stream-id",
		"a=extmap:11 urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id",
		"a=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time",
		"a=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01",
		"a=extmap:13 urn:3gpp:video-orientation",
		"a=extmap:14 urn:ietf:params:rtp-hdrext:toffset",
		"a=extmap:5 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay",
		"a=recvonly",
		"a=rtcp-mux",
		"a=rtcp-rsize",
		"a=rtpmap:96 VP8/90000",
		"a=rtcp-fb:96 transport-cc",
		"a=rtcp-fb:96 ccm fir",
		"a=rtcp-fb:96 nack",
		"a=rtcp-fb:96 nack pli",
		"a=fmtp:96 x-google-start-bitrate=1000",
		"a=rtpmap:97 rtx/90000",
		"a=fmtp:97 apt=96",
		"a=simple",
	}

	// Add ICE candidates
	sdpLines = append(sdpLines)

	return strings.Join(sdpLines, "\r\n") + "\r\n"
}
