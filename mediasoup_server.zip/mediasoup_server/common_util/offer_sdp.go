package common_util

import (
	"fmt"
	"mediasoup_server/bean"
	"strings"
	"time"
)

func GenerateOfferSdp(dtls bean.Dtls, consumers map[string]bean.Consumer) string {
	//通道参数
	icePwd := dtls.Data.IceParameters.Password
	iceUfrag := dtls.Data.IceParameters.UsernameFragment
	var fingerprint = ""
	for _, fp := range dtls.Data.DtlsParameters.Fingerprints {
		if fp.Algorithm == "sha-256" {
			fingerprint = fp.Value
			break
		}
	}
	var audioSsrc int
	var videoSsrc1 int
	var videoSsrc2 int
	for _, consumer := range consumers {
		kind := consumer.Kind
		if kind == "audio" {
			audioSsrc = int(consumer.RtpParameters.Encodings[0].Ssrc + 5)
		} else {
			videoSsrc1 = int(consumer.RtpParameters.Encodings[0].Ssrc + 5)
			videoSsrc2 = int(consumer.RtpParameters.Encodings[0].Rtx["ssrc"] + 5)
		}
	}
	var udpCandidate = ""
	ip := ""
	var port int
	candidates := dtls.Data.IceCandidates
	for _, cand := range candidates {
		if cand.Protocol == "udp" {
			udpCandidate = fmt.Sprintf(
				"a=candidate:%s 1 %s %d %s %d typ %s generation 0",
				cand.Foundation,
				cand.Protocol,
				cand.Priority,
				cand.IP,
				cand.Port,
				cand.Type,
			)
		}
		if port == 0 {
			port = cand.Port
		}
		ip = cand.IP
	}
	audioMid := "0"
	videoMid := "1"
	now := time.Now()
	unixNano := now.UnixNano()
	origin := fmt.Sprintf("o=- %d 2 IN IP4 127.0.0.1", unixNano)
	sdpLines := []string{
		"v=0",
		origin,
		"s=-",
		"t=0 0",
		fmt.Sprintf("a=group:BUNDLE %s %s", audioMid, videoMid),
		"a=msid-semantic: WMS 9402e535-8d9a-4b5a-8806-8951556878",
		"a=ice-lite",
		fmt.Sprintf("m=audio %d UDP/TLS/RTP/SAVPF 100", port),
		"a=msid:9402e535-8d9a-4b5a-8806-8951556878 audio-01",
		fmt.Sprintf("a=mid:%s", audioMid),
		fmt.Sprintf("c=IN IP4 %s", ip),
		"a=rtcp:9 IN IP4 0.0.0.0",
		udpCandidate,
		fmt.Sprintf("a=ice-ufrag:%s", iceUfrag),
		fmt.Sprintf("a=ice-pwd:%s", icePwd),
		"a=ice-options:renomination",
		fmt.Sprintf("a=fingerprint:%s %s", "sha-256", fingerprint),
		"a=setup:actpass",
		"a=extmap:1 urn:ietf:params:rtp-hdrext:sdes:mid",
		"a=extmap:4 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time",
		"a=extmap:5 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay",
		"a=extmap:11 urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id",
		"a=extmap:12 urn:ietf:params:rtp-hdrext:toffset",
		"a=sendonly",
		"a=rtcp-mux",
		"a=rtcp-rsize",
		"a=rtpmap:100 opus/48000/2",
		"a=rtcp-fb:100 transport-cc",
		"a=rtcp-fb:100 nack",
		fmt.Sprintf("a=ssrc:%d cname:audio-01", audioSsrc),
		fmt.Sprintf("a=ssrc:%d msid:9402e535-8d9a-4b5a-8806-8951556878 9402e535-8d9a-4b5a-8806-8951500001", audioSsrc),
		fmt.Sprintf("m=video %d UDP/TLS/RTP/SAVPF 101 102", port),
		fmt.Sprintf("c=IN IP4 %s", ip),
		"a=rtcp:9 IN IP4 0.0.0.0",
		udpCandidate,
		fmt.Sprintf("a=ice-ufrag:%s", iceUfrag),
		fmt.Sprintf("a=ice-pwd:%s", icePwd),
		"a=ice-options:renomination",
		fmt.Sprintf("a=fingerprint:%s %s", "sha-256", fingerprint),
		"a=setup:actpass",
		fmt.Sprintf("a=mid:%s", videoMid),
		"a=extmap:1 urn:ietf:params:rtp-hdrext:sdes:mid",
		"a=extmap:4 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time",
		"a=extmap:5 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay",
		"a=extmap:11 urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id",
		"a=extmap:12 urn:ietf:params:rtp-hdrext:toffset",
		"a=sendonly",
		"a=msid:9402e535-8d9a-4b5a-8806-8951556878 video-01",
		"a=extmap-allow-mixed",
		"a=rtcp-mux",
		"a=rtcp-rsize",
		"a=rtpmap:101 VP8/90000",
		"a=rtcp-fb:101 transport-cc",
		"a=rtcp-fb:101 ccm fir",
		"a=rtcp-fb:101 nack",
		"a=rtcp-fb:101 nack pli",
		"a=rtpmap:102 rtx/90000",
		"a=fmtp:102 apt=101",
		fmt.Sprintf("a=ssrc-group:FID %d %d", videoSsrc1, videoSsrc2),
		fmt.Sprintf("a=ssrc:%d cname:video-01", videoSsrc1),
		fmt.Sprintf("a=ssrc:%d cname:video-01", videoSsrc2),
	}

	// Add ICE candidates
	sdpLines = append(sdpLines)

	return strings.Join(sdpLines, "\r\n") + "\r\n"
}
