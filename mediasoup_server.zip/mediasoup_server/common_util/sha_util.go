package common_util

import (
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"crypto/x509"
	"encoding/hex"
	"fmt"
	"hash"
	"strings"
)

type FingerprintAlgorithm int

const (
	NONE FingerprintAlgorithm = iota
	SHA1
	SHA224
	SHA256
	SHA384
	SHA512
)

// string2FingerprintAlgorithm 是算法名称到枚举的映射
var string2FingerprintAlgorithm = map[string]FingerprintAlgorithm{
	"sha-1":   SHA1,
	"sha-224": SHA224,
	"sha-256": SHA256,
	"sha-384": SHA384,
	"sha-512": SHA512,
}

// GenerateFingerprints 生成证书的所有指纹，并返回 map[算法名称]指纹
func GenerateFingerprints(cert *x509.Certificate) (map[string]string, error) {
	fingerprints := make(map[string]string)

	for algoName, algo := range string2FingerprintAlgorithm {
		var hashFunc hash.Hash
		switch algo {
		case SHA1:
			hashFunc = sha1.New()
		case SHA224:
			hashFunc = sha256.New224()
		case SHA256:
			hashFunc = sha256.New()
		case SHA384:
			hashFunc = sha512.New384()
		case SHA512:
			hashFunc = sha512.New()
		default:
			return nil, fmt.Errorf("unknown algorithm: %s", algoName)
		}

		// 计算证书的哈希值
		if _, err := hashFunc.Write(cert.Raw); err != nil {
			return nil, fmt.Errorf("failed to compute hash: %v", err)
		}
		hashSum := hashFunc.Sum(nil)

		// 转换为十六进制，并用冒号分隔（如 "A1:B2:C3..."）
		hexFingerprint := strings.ToUpper(hex.EncodeToString(hashSum))
		var formattedFingerprint strings.Builder
		for i := 0; i < len(hexFingerprint); i += 2 {
			if i > 0 {
				formattedFingerprint.WriteString(":")
			}
			formattedFingerprint.WriteString(hexFingerprint[i : i+2])
		}

		fingerprints[algoName] = formattedFingerprint.String()
	}

	return fingerprints, nil
}
