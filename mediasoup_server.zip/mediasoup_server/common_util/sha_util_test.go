package common_util

import "testing"

func TestGenerateFingerprints(t *testing.T) {

}
