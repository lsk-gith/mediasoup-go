package sdp_util

import (
	"fmt"
	"strings"
)

// 定义输入参数结构体
type SDPParams struct {
	Codecs          []Codec           `json:"codecs"`
	HeaderExtension []HeaderExtension `json:"headerExtensions"`
	// 新增字段
	DtlsParameters DtlsParameters `json:"dtlsParameters"`
	IceCandidates  []IceCandidate `json:"iceCandidates"`
	IceParameters  IceParameters  `json:"iceParameters"`
}

type Codec struct {
	Kind                 string         `json:"kind"`
	MimeType             string         `json:"mimeType"`
	ClockRate            int            `json:"clockRate"`
	Channels             int            `json:"channels,omitempty"` // 仅音频需要
	RtcpFeedback         []RtcpFeedback `json:"rtcpFeedback"`
	Parameters           map[string]any `json:"parameters"`
	PreferredPayloadType int            `json:"preferredPayloadType"`
}
type RtcpFeedback struct {
	Type      string `json:"type"`
	Parameter string `json:"parameter"`
}

type HeaderExtension struct {
	Kind             string `json:"kind"`
	Uri              string `json:"uri"`
	PreferredId      int    `json:"preferredId"`
	PreferredEncrypt bool   `json:"preferredEncrypt"`
	Direction        string `json:"direction"`
}

// 新增结构体
type DtlsParameters struct {
	Fingerprints []Fingerprint `json:"fingerprints"`
	Role         string        `json:"role"`
}

type Fingerprint struct {
	Algorithm string `json:"algorithm"`
	Value     string `json:"value"`
}

type IceCandidate struct {
	Foundation string `json:"foundation"`
	Ip         string `json:"ip"`
	Port       int    `json:"port"`
	Priority   int    `json:"priority"`
	Protocol   string `json:"protocol"`
	Type       string `json:"type"`
	TcpType    string `json:"tcpType,omitempty"` // 仅 TCP 候选需要
}

type IceParameters struct {
	UsernameFragment string `json:"usernameFragment"`
	Password         string `json:"password"`
}

func GenerateSDP(params SDPParams) string {
	var sdp strings.Builder
	mediaMap := make(map[string][]Codec)
	extMap := make(map[string][]HeaderExtension)

	// 1. 按媒体类型分组编解码器和头扩展
	for _, codec := range params.Codecs {
		mediaMap[codec.Kind] = append(mediaMap[codec.Kind], codec)
	}
	for _, ext := range params.HeaderExtension {
		extMap[ext.Kind] = append(extMap[ext.Kind], ext)
	}

	// 2. 生成 SDP 基础信息
	sdp.WriteString("v=0\r\n")
	sdp.WriteString("o=- 0 0 IN IP4 127.0.0.1\r\n")
	sdp.WriteString("s=-\r\n")
	sdp.WriteString("t=0 0\r\n")

	// 3. 添加 ICE candidates 和 DTLS fingerprints
	sdp.WriteString(fmt.Sprintf("a=ice-ufrag:%s\r\n", params.IceParameters.UsernameFragment))
	sdp.WriteString(fmt.Sprintf("a=ice-pwd:%s\r\n", params.IceParameters.Password))

	// 添加 ICE 候选
	for _, cand := range params.IceCandidates {
		component := 1 // 固定为 RTP（component=1）
		line := fmt.Sprintf("a=candidate:%s %d %s %d %s %d typ %s",
			cand.Foundation, component, cand.Protocol, cand.Priority, cand.Ip, cand.Port, cand.Type)
		if cand.Protocol == "tcp" && cand.TcpType != "" {
			line += fmt.Sprintf(" tcptype %s", cand.TcpType)
		}
		sdp.WriteString(line + "\r\n")
	}

	// 添加 DTLS 指纹（取第一个）
	if len(params.DtlsParameters.Fingerprints) > 0 {
		fp := params.DtlsParameters.Fingerprints[0]
		sdp.WriteString(fmt.Sprintf("a=fingerprint:%s %s\r\n", fp.Algorithm, fp.Value))
		// 处理 setup 角色（auto 转为 active）
		setupRole := params.DtlsParameters.Role
		if setupRole == "auto" {
			setupRole = "active"
		}
		sdp.WriteString(fmt.Sprintf("a=setup:%s\r\n", setupRole))
	}

	// 4. 为每种媒体类型生成媒体块
	for mediaType, codecs := range mediaMap {
		// 生成 m= 行
		payloads := make([]string, 0, len(codecs))
		for _, c := range codecs {
			payloads = append(payloads, fmt.Sprintf("%d", c.PreferredPayloadType))
		}
		sdp.WriteString(fmt.Sprintf("m=%s 9 UDP/TLS/RTP/SAVPF %s\r\n",
			mapMediaType(mediaType),
			strings.Join(payloads, " "),
		))

		// 生成编解码器信息
		for _, codec := range codecs {
			rtpmap := fmt.Sprintf("%d %s/%d", codec.PreferredPayloadType, strings.Split(codec.MimeType, "/")[1], codec.ClockRate)
			if codec.Channels > 0 {
				rtpmap += fmt.Sprintf("/%d", codec.Channels)
			}
			sdp.WriteString(fmt.Sprintf("a=rtpmap:%s\r\n", rtpmap))

			// a=fmtp
			if len(codec.Parameters) > 0 {
				fmtpParams := make([]string, 0)
				for k, v := range codec.Parameters {
					fmtpParams = append(fmtpParams, fmt.Sprintf("%s=%v", k, v))
				}
				sdp.WriteString(fmt.Sprintf("a=fmtp:%d %s\r\n",
					codec.PreferredPayloadType,
					strings.Join(fmtpParams, ";"),
				))
			}

			// a=rtcp-fb
			for _, fb := range codec.RtcpFeedback {
				rtcpFb := fmt.Sprintf("a=rtcp-fb:%d %s", codec.PreferredPayloadType, fb.Type)
				if fb.Parameter != "" {
					rtcpFb += " " + fb.Parameter
				}
				sdp.WriteString(rtcpFb + "\r\n")
			}

			// 处理 RTX 关联
			if strings.HasSuffix(codec.MimeType, "/rtx") {
				if apt, ok := codec.Parameters["apt"].(float64); ok {
					sdp.WriteString(fmt.Sprintf("a=fmtp:%d apt=%d\r\n",
						codec.PreferredPayloadType, int(apt)))
				}
			}
		}

		// 5. 生成头扩展
		if exts, ok := extMap[mediaType]; ok {
			for _, ext := range exts {
				var dir string
				switch ext.Direction {
				case "sendrecv":
					dir = ""
				case "sendonly":
					dir = "/send"
				case "recvonly":
					dir = "/recv"
				default:
					dir = ""
				}
				sdp.WriteString(fmt.Sprintf("a=extmap:%d%s %s\r\n",
					ext.PreferredId, dir, ext.Uri))
			}
		}

		// 6. 添加公共属性
		sdp.WriteString("a=mid:" + mediaType + "\r\n")
		sdp.WriteString("a=rtcp-mux\r\n")
		sdp.WriteString("a=setup:active\r\n")
		sdp.WriteString("a=recvonly\r\n")
	}

	return sdp.String()
}

func mapMediaType(kind string) string {
	switch kind {
	case "audio":
		return "audio"
	case "video":
		return "video"
	default:
		return "application"
	}
}
