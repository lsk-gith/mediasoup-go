package sdp_util

import (
	"encoding/json"
	"fmt"
	"strings"
)

// 定义输入参数结构体
type SDPParams struct {
	Codecs          []Codec           `json:"codecs"`
	HeaderExtension []HeaderExtension `json:"headerExtensions"`
	// 新增字段
	DtlsParameters DtlsParameters `json:"dtlsParameters"`
	IceCandidates  []IceCandidate `json:"iceCandidates"`
	IceParameters  IceParameters  `json:"iceParameters"`
}

type Codec struct {
	Kind                 string         `json:"kind"`
	MimeType             string         `json:"mimeType"`
	ClockRate            int            `json:"clockRate"`
	Channels             int            `json:"channels,omitempty"` // 仅音频需要
	RtcpFeedback         []RtcpFeedback `json:"rtcpFeedback"`
	Parameters           map[string]any `json:"parameters"`
	PreferredPayloadType int            `json:"preferredPayloadType"`
}
type RtcpFeedback struct {
	Type      string `json:"type"`
	Parameter string `json:"parameter"`
}

type HeaderExtension struct {
	Kind             string `json:"kind"`
	Uri              string `json:"uri"`
	PreferredId      int    `json:"preferredId"`
	PreferredEncrypt bool   `json:"preferredEncrypt"`
	Direction        string `json:"direction"`
}

// 新增结构体
type DtlsParameters struct {
	Fingerprints []Fingerprint `json:"fingerprints"`
	Role         string        `json:"role"`
}

type Fingerprint struct {
	Algorithm string `json:"algorithm"`
	Value     string `json:"value"`
}

type IceCandidate struct {
	Foundation string `json:"foundation"`
	Ip         string `json:"ip"`
	Port       int    `json:"port"`
	Priority   int    `json:"priority"`
	Protocol   string `json:"protocol"`
	Type       string `json:"type"`
	TcpType    string `json:"tcpType,omitempty"` // 仅 TCP 候选需要
}

type IceParameters struct {
	UsernameFragment string `json:"usernameFragment"`
	Password         string `json:"password"`
}

func GenerateSDP(params SDPParams) string {
	var sdp strings.Builder
	mediaMap := make(map[string][]Codec)
	extMap := make(map[string][]HeaderExtension)

	// 1. 按媒体类型分组编解码器和头扩展
	for _, codec := range params.Codecs {
		mediaMap[codec.Kind] = append(mediaMap[codec.Kind], codec)
	}
	for _, ext := range params.HeaderExtension {
		extMap[ext.Kind] = append(extMap[ext.Kind], ext)
	}

	// 2. 生成 SDP 基础信息
	sdp.WriteString("v=0\r\n")
	sdp.WriteString("o=- 0 0 IN IP4 127.0.0.1\r\n")
	sdp.WriteString("s=-\r\n")
	sdp.WriteString("t=0 0\r\n")

	// 3. 添加 ICE candidates 和 DTLS fingerprints
	sdp.WriteString(fmt.Sprintf("a=ice-ufrag:%s\r\n", params.IceParameters.UsernameFragment))
	sdp.WriteString(fmt.Sprintf("a=ice-pwd:%s\r\n", params.IceParameters.Password))

	// 添加 ICE 候选
	for _, cand := range params.IceCandidates {
		component := 1 // 固定为 RTP（component=1）
		line := fmt.Sprintf("a=candidate:%s %d %s %d %s %d typ %s",
			cand.Foundation, component, cand.Protocol, cand.Priority, cand.Ip, cand.Port, cand.Type)
		if cand.Protocol == "tcp" && cand.TcpType != "" {
			line += fmt.Sprintf(" tcptype %s", cand.TcpType)
		}
		sdp.WriteString(line + "\r\n")
	}

	// 添加 DTLS 指纹（取第一个）
	if len(params.DtlsParameters.Fingerprints) > 0 {
		fp := params.DtlsParameters.Fingerprints[0]
		sdp.WriteString(fmt.Sprintf("a=fingerprint:%s %s\r\n", fp.Algorithm, fp.Value))
		// 处理 setup 角色（auto 转为 active）
		setupRole := params.DtlsParameters.Role
		if setupRole == "auto" {
			setupRole = "active"
		}
		sdp.WriteString(fmt.Sprintf("a=setup:%s\r\n", setupRole))
	}

	// 4. 为每种媒体类型生成媒体块
	for mediaType, codecs := range mediaMap {
		// 生成 m= 行
		payloads := make([]string, 0, len(codecs))
		for _, c := range codecs {
			payloads = append(payloads, fmt.Sprintf("%d", c.PreferredPayloadType))
		}
		sdp.WriteString(fmt.Sprintf("m=%s 9 UDP/TLS/RTP/SAVPF %s\r\n",
			mapMediaType(mediaType),
			strings.Join(payloads, " "),
		))

		// 生成编解码器信息
		for _, codec := range codecs {
			rtpmap := fmt.Sprintf("%d %s/%d", codec.PreferredPayloadType, strings.Split(codec.MimeType, "/")[1], codec.ClockRate)
			if codec.Channels > 0 {
				rtpmap += fmt.Sprintf("/%d", codec.Channels)
			}
			sdp.WriteString(fmt.Sprintf("a=rtpmap:%s\r\n", rtpmap))

			// a=fmtp
			if len(codec.Parameters) > 0 {
				fmtpParams := make([]string, 0)
				for k, v := range codec.Parameters {
					fmtpParams = append(fmtpParams, fmt.Sprintf("%s=%v", k, v))
				}
				sdp.WriteString(fmt.Sprintf("a=fmtp:%d %s\r\n",
					codec.PreferredPayloadType,
					strings.Join(fmtpParams, ";"),
				))
			}

			// a=rtcp-fb
			for _, fb := range codec.RtcpFeedback {
				rtcpFb := fmt.Sprintf("a=rtcp-fb:%d %s", codec.PreferredPayloadType, fb.Type)
				if fb.Parameter != "" {
					rtcpFb += " " + fb.Parameter
				}
				sdp.WriteString(rtcpFb + "\r\n")
			}

			// 处理 RTX 关联
			if strings.HasSuffix(codec.MimeType, "/rtx") {
				if apt, ok := codec.Parameters["apt"].(float64); ok {
					sdp.WriteString(fmt.Sprintf("a=fmtp:%d apt=%d\r\n",
						codec.PreferredPayloadType, int(apt)))
				}
			}
		}

		// 5. 生成头扩展
		if exts, ok := extMap[mediaType]; ok {
			for _, ext := range exts {
				var dir string
				switch ext.Direction {
				case "sendrecv":
					dir = ""
				case "sendonly":
					dir = "/send"
				case "recvonly":
					dir = "/recv"
				default:
					dir = ""
				}
				sdp.WriteString(fmt.Sprintf("a=extmap:%d%s %s\r\n",
					ext.PreferredId, dir, ext.Uri))
			}
		}

		// 6. 添加公共属性
		sdp.WriteString("a=mid:" + mediaType + "\r\n")
		sdp.WriteString("a=rtcp-mux\r\n")
		sdp.WriteString("a=setup:active\r\n")
		sdp.WriteString("a=recvonly\r\n")
	}

	return sdp.String()
}

func mapMediaType(kind string) string {
	switch kind {
	case "audio":
		return "audio"
	case "video":
		return "video"
	default:
		return "application"
	}
}

func GetSdp(ice json.RawMessage) string {
	//iceAndFinger := `{
	//	"consumerIds": [],
	//	"dataConsumerIds": [],
	//	"dataProducerIds": [],
	//	"direct": false,
	//	"dtlsParameters": {
	//		"fingerprints": [
	//			{
	//				"algorithm": "sha-256",
	//				"value": "A0:78:0B:80:63:0B:8E:16:29:FC:28:15:0C:24:CA:1E:08:D8:C4:40:50:C6:EA:5A:E6:92:4C:BD:11:D0:6A:C1"
	//			},
	//			{
	//				"algorithm": "sha-384",
	//				"value": "DE:5A:F2:8F:85:EF:3D:CB:1E:E1:14:C0:55:1A:27:CA:00:90:E7:F9:C3:14:6D:7C:E6:51:06:96:CA:5B:98:E6:8E:68:90:50:F3:08:C2:03:84:5E:07:76:03:33:DA:B7"
	//			},
	//			{
	//				"algorithm": "sha-224",
	//				"value": "30:56:A2:FA:C4:17:47:3D:4D:0C:28:77:3F:08:E0:B3:69:F2:E2:98:D9:82:C5:63:67:A0:B6:2F"
	//			},
	//			{
	//				"algorithm": "sha-1",
	//				"value": "EE:E2:9C:A1:F0:EC:86:AD:64:3C:FD:2B:7B:B7:4A:C3:06:03:38:3F"
	//			},
	//			{
	//				"algorithm": "sha-512",
	//				"value": "3D:48:03:9A:DE:D9:B5:10:2B:F0:8B:0C:5C:3C:68:AB:D4:85:80:7B:68:8A:C3:1F:F9:F1:E6:19:31:29:DB:3A:C9:A0:C0:F4:3B:4B:E6:B9:14:EE:23:9C:1C:E0:B5:BC:53:EA:9A:D5:0C:65:C6:65:B5:42:69:20:24:68:B2:72"
	//			}
	//		],
	//		"role": "auto"
	//	},
	//	"dtlsState": "new",
	//	"iceCandidates": [
	//		{
	//			"foundation": "udpcandidate",
	//			"ip": "192.168.12.244",
	//			"port": 50001,
	//			"priority": 1076302079,
	//			"protocol": "udp",
	//			"type": "host"
	//		},
	//		{
	//			"foundation": "tcpcandidate",
	//			"ip": "192.168.12.244",
	//			"port": 50001,
	//			"priority": 1076302079,
	//			"protocol": "tcp",
	//			"tcpType": "passive",
	//			"type": "host"
	//		}
	//	],
	//	"iceParameters": {
	//		"iceLite": true,
	//		"password": "l47xeoqgbo5ud5twqtkuzxnh8lyvimap",
	//		"usernameFragment": "7a5zke0qli7k3bveo7e8t79bqvwdokwz"
	//	},
	//	"iceRole": "controlled",
	//	"iceState": "new",
	//	"id": "t1",
	//	"mapRtxSsrcConsumerId": {},
	//	"mapSsrcConsumerId": {},
	//	"maxMessageSize": 262144,
	//	"producerIds": [],
	//	"recvRtpHeaderExtensions": {},
	//	"rtpListener": {
	//		"midTable": {},
	//		"ridTable": {},
	//		"ssrcTable": {}
	//	},
	//	"traceEventTypes": ""
	//}`

	jsonInput := `{
        "codecs": [
            {
                "kind": "audio",
                "mimeType": "audio/opus",
                "clockRate": 48000,
                "channels": 2,
                "rtcpFeedback": [
                    {
                        "type": "nack",
                        "parameter": ""
                    },
                    {
                        "type": "transport-cc",
                        "parameter": ""
                    }
                ],
                "parameters": {},
                "preferredPayloadType": 100
            },
            {
                "kind": "video",
                "mimeType": "video/VP8",
                "clockRate": 90000,
                "rtcpFeedback": [
                    {
                        "type": "nack",
                        "parameter": ""
                    },
                    {
                        "type": "nack",
                        "parameter": "pli"
                    },
                    {
                        "type": "ccm",
                        "parameter": "fir"
                    },
                    {
                        "type": "goog-remb",
                        "parameter": ""
                    },
                    {
                        "type": "transport-cc",
                        "parameter": ""
                    }
                ],
                "parameters": {
                    "x-google-start-bitrate": 1000
                },
                "preferredPayloadType": 101
            },
            {
                "kind": "video",
                "mimeType": "video/rtx",
                "preferredPayloadType": 102,
                "clockRate": 90000,
                "parameters": {
                    "apt": 101
                },
                "rtcpFeedback": []
            },
            {
                "kind": "video",
                "mimeType": "video/VP9",
                "clockRate": 90000,
                "rtcpFeedback": [
                    {
                        "type": "nack",
                        "parameter": ""
                    },
                    {
                        "type": "nack",
                        "parameter": "pli"
                    },
                    {
                        "type": "ccm",
                        "parameter": "fir"
                    },
                    {
                        "type": "goog-remb",
                        "parameter": ""
                    },
                    {
                        "type": "transport-cc",
                        "parameter": ""
                    }
                ],
                "parameters": {
                    "profile-id": 2,
                    "x-google-start-bitrate": 1000
                },
                "preferredPayloadType": 103
            },
            {
                "kind": "video",
                "mimeType": "video/rtx",
                "preferredPayloadType": 104,
                "clockRate": 90000,
                "parameters": {
                    "apt": 103
                },
                "rtcpFeedback": []
            },
            {
                "kind": "video",
                "mimeType": "video/H264",
                "clockRate": 90000,
                "parameters": {
                    "level-asymmetry-allowed": 1,
                    "packetization-mode": 1,
                    "profile-level-id": "4d0032",
                    "x-google-start-bitrate": 1000
                },
                "rtcpFeedback": [
                    {
                        "type": "nack",
                        "parameter": ""
                    },
                    {
                        "type": "nack",
                        "parameter": "pli"
                    },
                    {
                        "type": "ccm",
                        "parameter": "fir"
                    },
                    {
                        "type": "goog-remb",
                        "parameter": ""
                    },
                    {
                        "type": "transport-cc",
                        "parameter": ""
                    }
                ],
                "preferredPayloadType": 105
            },
            {
                "kind": "video",
                "mimeType": "video/rtx",
                "preferredPayloadType": 106,
                "clockRate": 90000,
                "parameters": {
                    "apt": 105
                },
                "rtcpFeedback": []
            },
            {
                "kind": "video",
                "mimeType": "video/H264",
                "clockRate": 90000,
                "parameters": {
                    "level-asymmetry-allowed": 1,
                    "packetization-mode": 1,
                    "profile-level-id": "42e01f",
                    "x-google-start-bitrate": 1000
                },
                "rtcpFeedback": [
                    {
                        "type": "nack",
                        "parameter": ""
                    },
                    {
                        "type": "nack",
                        "parameter": "pli"
                    },
                    {
                        "type": "ccm",
                        "parameter": "fir"
                    },
                    {
                        "type": "goog-remb",
                        "parameter": ""
                    },
                    {
                        "type": "transport-cc",
                        "parameter": ""
                    }
                ],
                "preferredPayloadType": 107
            },
            {
                "kind": "video",
                "mimeType": "video/rtx",
                "preferredPayloadType": 108,
                "clockRate": 90000,
                "parameters": {
                    "apt": 107
                },
                "rtcpFeedback": []
            }
        ],
        "headerExtensions": [
            {
                "kind": "audio",
                "uri": "urn:ietf:params:rtp-hdrext:sdes:mid",
                "preferredId": 1,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "urn:ietf:params:rtp-hdrext:sdes:mid",
                "preferredId": 1,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "urn:ietf:params:rtp-hdrext:sdes:rtp-stream-id",
                "preferredId": 2,
                "preferredEncrypt": false,
                "direction": "recvonly"
            },
            {
                "kind": "video",
                "uri": "urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id",
                "preferredId": 3,
                "preferredEncrypt": false,
                "direction": "recvonly"
            },
            {
                "kind": "audio",
                "uri": "http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time",
                "preferredId": 4,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time",
                "preferredId": 4,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "audio",
                "uri": "http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01",
                "preferredId": 5,
                "preferredEncrypt": false,
                "direction": "recvonly"
            },
            {
                "kind": "video",
                "uri": "http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01",
                "preferredId": 5,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "http://tools.ietf.org/html/draft-ietf-avtext-framemarking-07",
                "preferredId": 6,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "urn:ietf:params:rtp-hdrext:framemarking",
                "preferredId": 7,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "audio",
                "uri": "urn:ietf:params:rtp-hdrext:ssrc-audio-level",
                "preferredId": 10,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "urn:3gpp:video-orientation",
                "preferredId": 11,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "urn:ietf:params:rtp-hdrext:toffset",
                "preferredId": 12,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "audio",
                "uri": "http://www.webrtc.org/experiments/rtp-hdrext/abs-capture-time",
                "preferredId": 13,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "http://www.webrtc.org/experiments/rtp-hdrext/abs-capture-time",
                "preferredId": 13,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "audio",
                "uri": "http://www.webrtc.org/experiments/rtp-hdrext/playout-delay",
                "preferredId": 14,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            },
            {
                "kind": "video",
                "uri": "http://www.webrtc.org/experiments/rtp-hdrext/playout-delay",
                "preferredId": 14,
                "preferredEncrypt": false,
                "direction": "sendrecv"
            }
        ]
    }`
	var iceData struct {
		DtlsParameters struct {
			Fingerprints []Fingerprint `json:"fingerprints"`
			Role         string        `json:"role"`
		} `json:"dtlsParameters"`
		IceCandidates []IceCandidate `json:"iceCandidates"`
		IceParameters struct {
			UsernameFragment string `json:"usernameFragment"`
			Password         string `json:"password"`
		} `json:"iceParameters"`
	}
	if err := json.Unmarshal([]byte(ice), &iceData); err != nil {
		panic(err)
	}

	var params SDPParams
	if err := json.Unmarshal([]byte(jsonInput), &params); err != nil {
		panic(err)
	}

	params.DtlsParameters = iceData.DtlsParameters
	params.IceCandidates = iceData.IceCandidates
	params.IceParameters.UsernameFragment = iceData.IceParameters.UsernameFragment
	params.IceParameters.Password = iceData.IceParameters.Password

	sdp := GenerateSDP(params)
	return sdp
}
