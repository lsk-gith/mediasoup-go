package worker

import (
	"bufio"
	"encoding/json"
	"fmt"
	"github.com/gorilla/websocket"
	"io"
	"log"
	"mediasoup_server/bean"
	"mediasoup_server/common_util"
	"net"
	"os"
	"os/exec"
	"runtime/debug"
	"strconv"
	"sync"
	"syscall"
	"time"
)

var workerManager *WorkerManager

var (
	userIdUserMap     = sync.Map{}
	roomMap           = sync.Map{}
	userIdConnMap     = sync.Map{}
	workerIdUserIdMap = sync.Map{}
	fingerMap         = sync.Map{}
	localIp           string
)

func StartWorker(ip string) {
	localIp = ip
	fmt.Printf("localIp: %s\n", localIp)
	workerManager = StartMediasoupWorker()
	var msg = strconv.FormatInt(common_util.GneId(), 10) + ":worker.createWebRtcServer::{\"listenInfos\":[{\"protocol\":\"udp\",\"ip\":\"" + localIp + "\",\"port\":44445},{\"protocol\":\"tcp\",\"ip\":\"" + localIp + "\",\"port\":44445}],\"webRtcServerId\":\"001\"}"
	workerMsgBytes := []byte(msg + "\000")
	raw := common_util.Encode(workerMsgBytes)
	if _, err := workerManager.ProducerSocket.Write(raw); err != nil {
		fmt.Printf("workerManager.ProducerSocket.Write err:%s\n", err)
	}
	log.Printf("Sending message to worker: %s", string(raw))
}

type WorkerManager struct {
	ProducerSocket net.Conn // 用于发送数据到子进程
	ConsumerSocket net.Conn // 用于接收子进程的响应
	closed         bool
	mutex          sync.Mutex
}

func NewWorkerManager(producerConn, consumerConn net.Conn) *WorkerManager {
	wm := &WorkerManager{
		ProducerSocket: producerConn,
		ConsumerSocket: consumerConn,
		closed:         false,
	}
	go wm.readLoop()
	return wm
}
func (wm *WorkerManager) Close() {
	wm.mutex.Lock()
	defer wm.mutex.Unlock()
	if !wm.closed {
		wm.closed = true
		wm.ProducerSocket.Close()
		wm.ConsumerSocket.Close()
	}
}

func (wm *WorkerManager) processNSPayload(nsPayload []byte) {
	switch nsPayload[0] {
	case '{':
		if err := ProcessWorkerMessage(nsPayload); err != nil {
			fmt.Printf("processMessage err:%v", err)
		}
	default:
		fmt.Printf("[processNSPayload] unexpected data:%s", string(nsPayload))
	}
}
func (wm *WorkerManager) readLoop() {
	decoder := common_util.NewDecoder()
	go func() {
		if err := recover(); err != nil {
			fmt.Printf("channel panic, err:%v stack:%s, time:%v\n", err, debug.Stack(), time.Now())
		}
		for nsPayload := range decoder.Result() {
			wm.processNSPayload(nsPayload)
		}
	}()
	buf := make([]byte, 4194304)
	for {
		n, err := wm.ConsumerSocket.Read(buf)
		if err != nil {
			fmt.Printf("rcv from worker, read error: %v", err)
		}
		data := buf[:n]
		decoder.Feed(data)
	}
	wm.Close()
}

func StartMediasoupWorker() *WorkerManager {
	// 创建socketpair
	producerPair, err := createSocketPair()
	if err != nil {
		log.Printf("Failed to create producer pair: %v", err)
		return nil
	}
	consumerPair, err := createSocketPair()
	if err != nil {
		log.Printf("Failed to create consumer pair: %v", err)
		return nil
	}
	producerSocket, err := fileToConn(producerPair[0])
	if err != nil {
		log.Printf("Failed to create producer socket: %v", err)
		return nil
	}
	consumerSocket, err := fileToConn(consumerPair[0])
	if err != nil {
		log.Printf("Failed to create consumer socket: %v", err)
		return nil
	}
	// mediasoup-worker的参数
	args := []string{
		"--logLevel=debug",
		"--logTag=info",
		"--logTag=ice",
		"--logTag=dtls",
		"--logTag=rtp",
		"--logTag=srtp",
		"--logTag=rtcp",
		"--logTag=rtx",
		"--logTag=bwe",
		"--logTag=score",
		"--logTag=simulcast",
		"--logTag=svc",
		"--logTag=sctp",
		"--logTag=message",
		"--logTag=rtmp",
		"--logTag=fec",
		"--logTag=http_client",
		"--rtcMinPort=40000",
		"--rtcMaxPort=49999",
	}
	cmd := exec.Command("./bin/mediasoup-worker", args...)
	cmd.ExtraFiles = []*os.File{producerPair[1], consumerPair[1]}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		fmt.Printf("[newWorker] stdout. err:%v", err)
		return nil
	}
	var stderr io.ReadCloser
	stderr, err = cmd.StderrPipe()
	if err != nil {
		fmt.Printf("[newWorker] stderr. err:%v", err)
		return nil
	}
	err = cmd.Start()
	if err != nil {
		log.Fatalf("Failed to start mediasoup-worker: %v", err)
	}
	producerPair[0].Close()
	consumerPair[0].Close()
	pid := cmd.Process.Pid
	go func() {
		r := bufio.NewReader(stderr)
		for {
			line, _, err := r.ReadLine()
			if err != nil {
				break
			}
			if len(line) > 0 {
				fmt.Printf("child[%d] worker stderr line:%s", pid, line)
			}
		}
	}()
	go func() {
		r := bufio.NewReader(stdout)
		for {
			line, _, err := r.ReadLine()
			if err != nil {
				break
			}
			if len(line) > 0 {
				fmt.Printf("child[%d] worker stdout line:%s", pid, line)
			}
		}
	}()
	workerManager := NewWorkerManager(producerSocket, consumerSocket)
	go func() {
		err := cmd.Wait()
		if err != nil {
			log.Printf("mediasoup-worker exited with error: %v", err)
		} else {
			log.Printf("mediasoup-worker exited normally")
		}
		workerManager.Close()
	}()
	return workerManager
}

func fileToConn(file *os.File) (net.Conn, error) {
	conn, err := net.FileConn(file)
	if err != nil {
		file.Close()
		return nil, err
	}
	return conn, nil
}

func createSocketPair() (file [2]*os.File, err error) {
	fd, err := syscall.Socketpair(syscall.AF_LOCAL, syscall.SOCK_STREAM, 0)
	if err != nil {
		fmt.Println("[createSocketPair] syscall.socketpair failed. err:%v", err)
		return file, err
	}
	file[0] = os.NewFile(uintptr(fd[0]), "")
	file[1] = os.NewFile(uintptr(fd[1]), "")
	return
}

func ProcessWorkerMessage(nsPayload []byte) error {
	parseWorkerMsg(nsPayload)
	return nil
}

func parseWorkerMsg(payload []byte) {
	payloadCopy := make([]byte, len(payload))
	copy(payloadCopy, payload)
	go func() {
		fmt.Printf("worker payload:%s\n", string(payloadCopy))
		response(payloadCopy)
	}()
}

func response(payload []byte) {

	var workerMsg map[string]interface{}
	err := json.Unmarshal(payload, &workerMsg)
	if err != nil {
		return
	}
	userId := ""
	var answer = map[string]string{}
	var workerId int64
	if id, exist := workerMsg["id"].(float64); exist {
		workerId = int64(id)
		value, ok := workerIdUserIdMap.Load(strconv.FormatInt(workerId, 10))
		if ok {
			userId = value.(string)
		}
	}
	var user *bean.User
	if value, exist := userIdUserMap.Load(userId); exist {
		user = value.(*bean.User)
	}
	if user == nil {
		return
	}
	idMap := user.WorkerIdTransportIdMap
	transportId := idMap[workerId]
	if value, exist := workerMsg["data"]; exist {
		if value == nil {
			return
		}
		var dtls bean.Dtls
		err = json.Unmarshal(payload, &dtls)
		if err != nil {
			fmt.Printf("[parseWorkerMsg] json.Unmarshal err:%v\n", err)
			return
		}
		if user.Producer.TransportId == transportId {
			//上行逻辑
			var sha_value = ""
			user.Producer.Dtls = dtls
			for _, fp := range dtls.Data.DtlsParameters.Fingerprints {
				if fp.Algorithm == "sha-256" {
					sha_value = fp.Value
					break
				}
			}
			password := dtls.Data.IceParameters.Password
			fragment := dtls.Data.IceParameters.UsernameFragment
			if sha_value == "" {
				return
			}
			sdp := common_util.GenerateUpAnswerSDP(fragment, password, sha_value, "sha-256", dtls.Data.IceCandidates)
			answer["sdp"] = sdp
			answer["type"] = "answer"
			fmt.Printf(" answer SDP: %v", sdp)
			if channel, o := userIdConnMap.Load(userId); o {
				if channel == nil {
					return
				}
				var answerSdp = make(map[string]interface{})
				answerSdp["type"] = "answer"
				answerSdp["answer"] = answer
				conn, ok1 := channel.(*websocket.Conn)
				if ok1 {
					marshal, _ := json.Marshal(answerSdp)
					conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
					conn.WriteMessage(websocket.TextMessage, marshal)
				}
			}
		}
		if user.Consumer.TransportId == transportId {
			//下行逻辑
			user.Consumer.Dtls = dtls
		}

	}

}

func ProcessDownAnswerSdp(message []byte, conn *websocket.Conn) error {
	var answer bean.AnswerReq
	err := json.Unmarshal(message, &answer)
	if err != nil {
		fmt.Printf("[ProcessDownAnswerSdp] json.Unmarshal err:%v\n", err)
		return err
	}
	userId := answer.UserId
	value, ok := userIdUserMap.Load(userId)
	if !ok {
		return fmt.Errorf("userId:%d not exist", userId)
	}
	user := value.(*bean.User)
	user.Mu.Lock()
	defer user.Mu.Unlock()
	//1、需要解析出来，dtls参数给worker实现connect
	name, content := common_util.GetFingerNameContent(answer.Answer.Sdp)
	producerTransportId := user.Consumer.TransportId
	id := common_util.GneId()
	idStr := strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg := idStr + ":transport.connect:" + producerTransportId + ":{\"dtlsParameters\":{\"fingerprints\": [{\"algorithm\":\"" + name + "\",\"value\":\"" + content + "\"}],\"role\":\"client\"}}"
	workerMsgBytes := []byte(msg + "\000")
	raw := common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}
	time.Sleep(500 * time.Millisecond)
	//2、需要向worker发起consume请求 该步骤应该在transport connection之后再transport.consume

	remoteConsumer := user.Consumer.Consumers
	producerId := ""
	consumerId := ""
	for _, consumers := range remoteConsumer {
		for _, consumer := range consumers {
			consumerId = consumer.ConsumerId
			producerId = consumer.ProducerId
			kind := consumer.Kind
			encodings := consumer.ConsumableRtpEncodings
			parameters := consumer.RtpParameters
			for i, _ := range parameters.Encodings {
				if kind == "video" {
					parameters.Encodings[i].Rtx["ssrc"] = parameters.Encodings[i].Rtx["ssrc"] + 5
					encodings[i].Dtx = false
				}
			}
			req := make(map[string]interface{})
			req["consumerId"] = consumerId
			req["producerId"] = producerId
			req["kind"] = kind
			req["type"] = "simple"
			req["rtpParameters"] = parameters
			req["paused"] = true
			req["consumableRtpEncodings"] = encodings
			req["ignoreDtx"] = false
			marshal, _ := json.Marshal(req)
			id = common_util.GneId()
			idStr = strconv.FormatInt(id, 10)
			workerIdUserIdMap.Store(idStr, userId)
			msg = idStr + ":transport.consume:" + producerTransportId + ":" + string(marshal)
			workerMsgBytes = []byte(msg + "\000")
			raw = common_util.Encode(workerMsgBytes)
			if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
				return err
			}
			id = common_util.GneId()
			idStr = strconv.FormatInt(id, 10)
			workerIdUserIdMap.Store(idStr, userId)
			msg = idStr + ":consumer.resume:" + consumerId + ":{}"
			workerMsgBytes = []byte(msg + "\000")
			raw = common_util.Encode(workerMsgBytes)
			if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
				return err
			}
		}
	}

	return nil
}

// 上行offerSdp
func ProcessUpOfferSdp(message []byte, conn *websocket.Conn) error {
	var offer bean.OfferReq
	err := json.Unmarshal(message, &offer)
	if err != nil {
		return err
	}
	roomId := offer.RoomId
	userId := offer.UserId
	userIdConnMap.Store(userId, conn)
	if value, ok := userIdUserMap.Load(userId); ok {
		user := value.(*bean.User)
		user.Conn = conn
		user.RoomId = roomId
		user.WorkerIdTransportIdMap = make(map[int64]string)
	} else {
		user := bean.User{
			Conn:                   conn,
			UserId:                 userId,
			RoomId:                 roomId,
			WorkerIdTransportIdMap: make(map[int64]string),
		}
		userIdUserMap.Store(userId, &user)
	}
	temp, _ := userIdUserMap.Load(userId)
	user := temp.(*bean.User)
	user.Mu.Lock()
	defer user.Mu.Unlock()
	fmt.Printf("roomId:%v userId:%v\n", roomId, userId)
	value, ok := roomMap.Load(roomId)
	var activeSpeakerObserverId string
	var audioLevelObserverId string
	if ok && value != nil {
		fmt.Printf("roomId:%v alread exist", roomId)
		observerMap := value.(map[string]string)
		activeSpeakerObserverId = observerMap["activeSpeakerObserverId"]
		audioLevelObserverId = observerMap["audioLevelObserverId"]
	} else {
		//创建房间，保存map
		id := common_util.GneId()
		idStr := strconv.FormatInt(id, 10)
		msg := idStr + ":worker.createRouter:req-123:{\"routerId\":\"" + roomId + "\"}"
		workerMsgBytes := []byte(msg + "\000")
		raw := common_util.Encode(workerMsgBytes)
		if _, err := workerManager.ProducerSocket.Write(raw); err != nil {
			return err
		}
		audioLevelObserverId = common_util.RandStringBytes(10)
		id = common_util.GneId()
		idStr = strconv.FormatInt(id, 10)
		msg = idStr + ":router.createAudioLevelObserver:" + roomId + ":{\"rtpObserverId\":\"" + audioLevelObserverId + "\",\"maxEntries\":1,\"threshold\":-80,\"interval\":800}"
		workerMsgBytes = []byte(msg + "\000")
		raw = common_util.Encode(workerMsgBytes)
		if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
			return err
		}
		log.Printf("Sending message to worker: %s", string(raw))
		activeSpeakerObserverId = common_util.RandStringBytes(10)
		id = common_util.GneId()
		idStr = strconv.FormatInt(id, 10)
		msg = idStr + ":router.createActiveSpeakerObserver:" + roomId + ":{\"rtpObserverId\":\"" + activeSpeakerObserverId + "\",\"interval\":300}"
		workerMsgBytes = []byte(msg + "\000")
		raw = common_util.Encode(workerMsgBytes)
		if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
			return err
		}
		observerMap := map[string]string{}
		observerMap["audioLevelObserverId"] = audioLevelObserverId
		observerMap["activeSpeakerObserverId"] = activeSpeakerObserverId
		roomMap.Store(roomId, observerMap)
	}

	producerTransportId := common_util.RandStringBytes(10)
	producerTransport := bean.ProducerTransport{
		TransportId: producerTransportId,
		Producers:   make(map[string]bean.MediaParameters),
	}
	user.Producer = producerTransport
	id := common_util.GneId()
	idStr := strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	user.WorkerIdTransportIdMap[id] = producerTransportId
	msg := idStr + ":router.createWebRtcTransportWithServer:" + roomId + ":{\"transportId\":\"" + producerTransportId + "\",\"listenIps\":[{\"ip\":\"" + localIp + "\"}],\"webRtcServerId\":\"001\",\"enableUdp\":true,\"enableTcp\":false,\"preferUdp\":false,\"preferTcp\":false,\"initialAvailableOutgoingBitrate\":1000000,\"enableSctp\":true,\"numSctpStreams\":{\"OS\":1024,\"MIS\":1024},\"maxSctpMessageSize\":262144,\"sctpSendBufferSize\":262144,\"isDataChannel\":true}"
	workerMsgBytes := []byte(msg + "\000")
	raw := common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}

	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.enableTraceEvent:" + producerTransportId + ":{\"types\":[\"bwe\"]}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}
	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.setMaxIncomingBitrate:" + producerTransportId + ":{\"bitrate\":1500000}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}
	name, content := common_util.GetFingerNameContent(offer.Offer.Sdp)
	fingerMap.Store(name, content)

	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.connect:" + producerTransportId + ":{\"dtlsParameters\":{\"fingerprints\": [{\"algorithm\":\"" + name + "\",\"value\":\"" + content + "\"}],\"role\":\"auto\"}}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}

	consumerTransportId := common_util.RandStringBytes(10)
	var consumerTransport = bean.ConsumerTransport{
		TransportId: consumerTransportId,
		Consumers:   make(map[string]map[string]bean.Consumer),
	}
	user.Consumer = consumerTransport
	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	user.WorkerIdTransportIdMap[id] = consumerTransportId
	msg = idStr + ":router.createWebRtcTransportWithServer:" + roomId + ":{\"transportId\":\"" + consumerTransportId + "\",\"listenIps\":[{\"ip\":\"" + localIp + "\"}],\"webRtcServerId\":\"001\",\"enableUdp\":true,\"enableTcp\":false,\"preferUdp\":false,\"preferTcp\":false,\"initialAvailableOutgoingBitrate\":1000000,\"enableSctp\":true,\"numSctpStreams\":{\"OS\":1024,\"MIS\":1024},\"maxSctpMessageSize\":262144,\"sctpSendBufferSize\":262144,\"isDataChannel\":true}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}

	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.enableTraceEvent:" + consumerTransportId + ":{\"types\":[\"bwe\"]}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}
	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.setMaxIncomingBitrate:" + consumerTransportId + ":{\"bitrate\":1500000}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}
	audioParams, videoParams, err := common_util.ParseUpOfferSDP(offer.Offer.Sdp)
	if err != nil {
		return err
	}
	audioProduceId := common_util.RandStringBytes(10)
	videoProduceId := common_util.RandStringBytes(10)
	audioParams.ProducerId = audioProduceId
	videoParams.ProducerId = videoProduceId
	producerTransport.Producers[audioProduceId] = audioParams
	producerTransport.Producers[videoProduceId] = videoParams
	audio, err := json.Marshal(audioParams)
	if err != nil {
		return err
	}
	video, err := json.Marshal(videoParams)
	if err != nil {
		return err
	}
	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.produce:" + producerTransportId + ":" + string(audio)
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}

	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":rtpObserver.addProducer:" + audioLevelObserverId + ":{\"producerId\":\"" + audioProduceId + "\"}"
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}

	id = common_util.GneId()
	idStr = strconv.FormatInt(id, 10)
	workerIdUserIdMap.Store(idStr, userId)
	msg = idStr + ":transport.produce:" + producerTransportId + ":" + string(video)
	workerMsgBytes = []byte(msg + "\000")
	raw = common_util.Encode(workerMsgBytes)
	if _, err = workerManager.ProducerSocket.Write(raw); err != nil {
		return err
	}

	//下行订阅
	roomUsers := getRoomUsers(roomId)
	if len(roomUsers) <= 1 {
		return nil
	}
	for _, notifyUser := range roomUsers {
		notifyUserId := notifyUser.UserId
		users := getRoomUsersExcludeUserId(roomId, notifyUserId)
		fmt.Printf("notifyUserId:%s and otherusers size:%d\n", notifyUser.UserId, len(users))
		//先关闭之前的流
		//for key, _ := range notifyUser.Consumer.Consumers {
		//	notifyUser.Consumer.Consumers.
		//}
		//清理之前的consumer
		notifyUser.Consumer.Consumers = make(map[string]map[string]bean.Consumer)
		for _, otherUser := range users {
			remoteConsumer := map[string]bean.Consumer{}
			remoteUserId := otherUser.UserId
			for producerId, producer := range otherUser.Producer.Producers {
				//传给worker的parameters
				parameters := producer.RtpParameters
				consumableRtpEncodings := make([]bean.ConsumableRtpEncodings, 0)
				for i, ssrc := range producer.RtpMapping.Encodings {
					if i == 0 {
						consumableRtpEncodings = append(consumableRtpEncodings, bean.ConsumableRtpEncodings{
							Ssrc: ssrc.MappedSsrc,
						})
					}
				}
				for i, _ := range parameters.Encodings {
					parameters.Encodings[i].Ssrc += common_util.GenerateSsrc()
				}
				if producer.Kind == "audio" {
					parameters.Mid = "0"
					for i, _ := range parameters.Codecs {
						parameters.Codecs[i].PayloadType = 100
						parameters.Rtcp = bean.Rtcp{
							Cname:       "audio-" + producerId,
							ReducedSize: true,
							Mux:         true,
						}
					}
				} else {
					parameters.Mid = "1"
					for i, codecs := range producer.RtpParameters.Codecs {
						if codecs.Parameters["apt"] != nil {
							codecs.Parameters["apt"] = 101
						}
						if codecs.PayloadType == 96 {
							parameters.Codecs[i].PayloadType = 101
						}
						if codecs.PayloadType == 97 {
							parameters.Codecs[i].PayloadType = 102
						}
					}
					parameters.Rtcp = bean.Rtcp{
						Cname:       "video-" + producerId,
						ReducedSize: true,
						Mux:         true,
					}
				}
				typeStr := "simple"
				consumerId := common_util.RandStringBytes(10)
				consumer := bean.Consumer{
					ProducerId:             producerId,
					Type:                   typeStr,
					ConsumerId:             consumerId,
					Kind:                   producer.Kind,
					RtpParameters:          parameters,
					ConsumableRtpEncodings: consumableRtpEncodings,
				}
				remoteConsumer[consumerId] = consumer
			}
			notifyUser.Consumer.Consumers[remoteUserId] = remoteConsumer
		}
		time.Sleep(1000 * time.Millisecond)
		temp, _ = userIdUserMap.Load(notifyUserId)
		notifyUser = temp.(*bean.User)
		dtls := notifyUser.Consumer.Dtls
		//组装 发送 offerSdp
		consumers := notifyUser.Consumer.Consumers
		sdp := common_util.GenerateDownOfferSdp(dtls, consumers)
		fmt.Printf("offerSdp: %v\n", sdp)
		var offerSdp = map[string]string{}
		offerSdp["sdp"] = sdp
		offerSdp["type"] = "offer"
		var offerSdpMap = make(map[string]interface{})
		offerSdpMap["type"] = "offer"
		offerSdpMap["offer"] = offerSdp
		offerSdpMapDetail, _ := json.Marshal(offerSdpMap)
		conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
		err = notifyUser.Conn.WriteMessage(websocket.TextMessage, offerSdpMapDetail)
		if err != nil {
			fmt.Printf("write offerSdp error: %v\n", err)
			//重试一次
			notifyUser.Conn.WriteMessage(websocket.TextMessage, offerSdpMapDetail)
		}
	}
	return nil
}

func getRoomUsersExcludeUserId(roomId, userId string) []*bean.User {
	res := make([]*bean.User, 0)
	userIdUserMap.Range(func(key, value any) bool {
		user := value.(*bean.User)
		if user.RoomId == roomId && user.UserId != userId {
			res = append(res, user)
		}
		return true
	})
	return res
}
func getRoomUsers(roomId string) []*bean.User {
	res := make([]*bean.User, 0)
	userIdUserMap.Range(func(key, value any) bool {
		user := value.(*bean.User)
		if user.RoomId == roomId {
			res = append(res, user)
		}
		return true
	})
	return res
}
